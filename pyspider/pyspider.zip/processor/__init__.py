from .processor import ProcessorResult, Processor
